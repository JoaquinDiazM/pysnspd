# pySNSPD: revisión documental 0.4

Actualización desde 0.3, 9 de septiembre de 2026. Los documentos editables están en esta carpeta; los cinco PDF y el ZIP están en `output/pdf/modelo_v0_4` desde la raíz del repositorio. La entrega completa se copia a `/home/jdiaz/pysnspd` en Geminga, conservando las rutas relativas.

Esta revisión contiene un candidato continuo **experimental y restringido**, no un cambio del solver de producción. El diagnóstico detecta sensibilidad de núcleo, pérdida del signo positivo del símbolo principal en ciertos estados y una DOS fonónica que no supera la admisión de unidades/normalización. No se ejecutaron PRE, SS ni transitorios fotónicos completos. Un balance preciso no equivale a validación material.

## Lectura

- **A:** funcional estático y catálogo Usadel; numeración consecutiva A.1–A.28 y mapa de equivalencias con 0.3.
- **B:** decisiones cinéticas seleccionadas, fuente efectiva definida desde el vacío, transporte, datos y pruebas independientes.
- **C:** origen del término de gradiente de fase, energía espacial finita, primera variación, circuito y diagnósticos del alcance físico y matemático.
- **D:** todas las ecuaciones continuas del candidato, condiciones de borde, tiempo, circuito, admisión y secuencia de implementación experimental.
- **E:** siete clases activas simplificadas. E02 retirada; E06/E07 sustituyen la clase antigua de Nambu. E05/E08 separan modos/DOS de DFPT. Se responden las 21 actividades en el Markdown; no hay clases aprobadas sin respuestas.

## Reproducción de los cálculos ligeros

Los programas `sandbox/model_v0_4/checks_a_v04.py`, `checks_b_v04.py`, `checks_c_v04.py`, `checks_d_v04.py` y `learning_v04.py` son propios de esta revisión y no importan el solver de producción. Se ejecutaron en Geminga con Python 3.10.20, NumPy 2.2.6, SciPy 1.15.3 y Matplotlib 3.10.8. A, B, C y D separan los ensayos físicos reducidos; E verifica sólo sus ejemplos resueltos, no respuestas a actividades.

Desde la raíz del repositorio en Geminga:

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
/home/jdiaz/.conda/envs/snspd/bin/python sandbox/model_v0_4/checks_a_v04.py
/home/jdiaz/.conda/envs/snspd/bin/python sandbox/model_v0_4/checks_b_v04.py --material /home/jdiaz/scratch/big_data/catalogs/simon_2025/nbn-a2f-ph.dat
/home/jdiaz/.conda/envs/snspd/bin/python sandbox/model_v0_4/checks_c_v04.py
/home/jdiaz/.conda/envs/snspd/bin/python sandbox/model_v0_4/checks_d_v04.py
/home/jdiaz/.conda/envs/snspd/bin/python sandbox/model_v0_4/learning_v04.py
```

B requiere la entrada original `/home/jdiaz/scratch/big_data/catalogs/simon_2025/nbn-a2f-ph.dat`; el programa acepta otra ubicación mediante `--material`. Su SHA-256 se registra en el JSON y en el manifiesto. El archivo se audita sin modificarlo y no se redistribuye. La trayectoria de colisiones utiliza un espectro normal/Debye sintético; el archivo NbN no se usa para ocultar una tasa absoluta sin normalización verificada.

Los resultados están en `verificaciones` como JSON/CSV y las figuras en `figuras` como PNG/PDF. Son 23 figuras distintas; las dos ilustraciones pedagógicas B_01 y B_05 se conservan de 0.3 como recursos estáticos, no como cálculos nuevos. Las otras figuras se generan en esta revisión. Los CSV y gráficos incluyen unidades sintéticas cuando corresponden.

Ejecutar de nuevo modifica resultados, metadatos y potencialmente hashes; para preservar la entrega aprobada conviene hacerlo en una copia. No se debe conservar el manifiesto anterior después de regenerar archivos.

## Construcción y control documental

`build_documents.py` requiere Pandoc (o pypandoc_binary) y genera las cinco fuentes LaTeX, con rutas relativas a figuras. `--compile` usa Tectonic si está disponible. En esta entrega Pandoc se ejecutó desde Windows y Tectonic 0.15.0 desde Geminga. Los registros finales de compilación están en `verificaciones/compilacion`.

`verify_artifacts.py` requiere pypdf: verifica etiquetas de ecuación, imágenes incrustadas, glifos de sustitución y advertencias de composición. Los registros `QA_visual_A.json` a `QA_visual_E.json` documentan la inspección de todas las páginas renderizadas con Poppler. Esa revisión visual se renueva si cambia un PDF.

`package_results.py` comprueba los hashes de los PDF revisados, consolida la revisión visual, crea `manifiesto_v0_4.json` y el ZIP, y verifica cada miembro del archivo. El verificador de distribución no depende de NumPy, Pandoc ni del solver:

```bash
/home/jdiaz/.conda/envs/snspd/bin/python sandbox/model_v0_4/verify_distribution.py
```

El manifiesto registra la revisión, el commit de referencia, los hashes de fuentes documentales disponibles y cada archivo de la entrega. La integridad final local y remota se guarda fuera del ZIP, junto a él, para no crear una dependencia circular entre el manifiesto y su propia comprobación.

`observaciones_v0_4_resumen.txt` es un resumen editorial de la solicitud directa del usuario, no una transcripción ni instrucciones extraídas de los documentos. Las referencias científicas y sus alcances se citan dentro de A–E. Las revisiones anteriores permanecen intactas.
